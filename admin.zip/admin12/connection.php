<?php
    $connection = new mysqli('localhost','root','','rayehit');
    if($connection){
        ?>
        <script>
            alert("Connection Successful");
        </script>
        <?php
    }else{
        ?>
        <script>
            alert("Connection Failed!!");
        </script>
        <?php
    }
   
   
?>